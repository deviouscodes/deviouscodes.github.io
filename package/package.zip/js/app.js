

//Colors
document.querySelector('#btn-mirage-g4').addEventListener ('click', function () {
  document.querySelector('#mirage-g4').className = 'current';
  document.querySelector('[data-position="current"]').className = 'left';
//  var myVideo=document.getElementById("mirage-g4-video"); 
//  myVideo.play(); 

//var video = document.getElementById("mirage-g4-video");
//   
//          video.pause();
//          video.currentTime = 0;

  
  });
document.querySelector('#btn-mirage-g4-back').addEventListener ('click', function () {
  document.querySelector('#mirage-g4').className = 'right';
  document.querySelector('[data-position="current"]').className = 'current';
// document.querySelector('#mirage-g4-video').pause();
// 
//document.querySelector('#mirage-g4-video').play();
});

//btn-virtualquote
document.querySelector('#btn-virtualquote').addEventListener ('click', function () {
  document.querySelector('#virtualquote').className = 'current';
  document.querySelector('[data-position="current"]').className = 'left';

  });
  document.querySelector('#btn-virtualquote-back').addEventListener ('click', function () {
  document.querySelector('#virtualquote').className = 'right';
  document.querySelector('[data-position="current"]').className = 'current';

});
//btn-virtualquoteresult
document.querySelector('#btn-virtualquoteresult').addEventListener ('click', function () {
  document.querySelector('#virtualquoteresult').className = 'current';
 document.querySelector('[data-position="current"]').className = 'left';

  });
  document.querySelector('#btn-virtualquoteresult-back').addEventListener ('click', function () {
  document.querySelector('#virtualquoteresult').className = 'right';
   document.querySelector('[data-position="current"]').className = 'current';

});
//Space
document.querySelector('#btn-greatspace').addEventListener ('click', function () {
  document.querySelector('#greatspace').className = 'current';
  document.querySelector('[data-position="current"]').className = 'left';

  });
  document.querySelector('#btn-greatspace-back').addEventListener ('click', function () {
  document.querySelector('#greatspace').className = 'right';
  document.querySelector('[data-position="current"]').className = 'current';

});
//value
document.querySelector('#btn-greatvalue').addEventListener ('click', function () {
  document.querySelector('#greatvalue').className = 'current';
  document.querySelector('[data-position="current"]').className = 'left';

  });
  document.querySelector('#btn-greatvalue-back').addEventListener ('click', function () {
  document.querySelector('#greatvalue').className = 'right';
  document.querySelector('[data-position="current"]').className = 'current';

});
//mileage
document.querySelector('#btn-greatmileage').addEventListener ('click', function () {
  document.querySelector('#greatmileage').className = 'current';
  document.querySelector('[data-position="current"]').className = 'left';

  });
  document.querySelector('#btn-greatmileage-back').addEventListener ('click', function () {
  document.querySelector('#greatmileage').className = 'right';
  document.querySelector('[data-position="current"]').className = 'current';

});

//safety
document.querySelector('#btn-greatsafety').addEventListener ('click', function () {
  document.querySelector('#greatsafety').className = 'current';
  document.querySelector('[data-position="current"]').className = 'left';

  });
  document.querySelector('#btn-greatsafety-back').addEventListener ('click', function () {
  document.querySelector('#greatsafety').className = 'right';
  document.querySelector('[data-position="current"]').className = 'current';

});
//handling
document.querySelector('#btn-greathandling').addEventListener ('click', function () {
  document.querySelector('#greathandling').className = 'current';
  document.querySelector('[data-position="current"]').className = 'left';

  });
  document.querySelector('#btn-greathandling-back').addEventListener ('click', function () {
  document.querySelector('#greathandling').className = 'right';
  document.querySelector('[data-position="current"]').className = 'current';

});
//accessories
document.querySelector('#btn-greataccessories').addEventListener ('click', function () {
  document.querySelector('#greataccessories').className = 'current';
  document.querySelector('[data-position="current"]').className = 'left';

  });
  document.querySelector('#btn-greataccessories-back').addEventListener ('click', function () {
  document.querySelector('#greataccessories').className = 'right';
  document.querySelector('[data-position="current"]').className = 'current';

});

//disclaim
//document.querySelector('#btn-disclaim').addEventListener ('click', function () {
//  document.querySelector('#disclaim').className = 'current';
//  document.querySelector('[data-position="current"]').className = 'left';
//
//  });
//  document.querySelector('#btn-disclaim-back').addEventListener ('click', function () {
//  document.querySelector('#disclaim').className = 'right';
//  document.querySelector('[data-position="current"]').className = 'current';
//
//});