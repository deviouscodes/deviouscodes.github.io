
function scrollToAnchor(id){
//documentElement.scrollTop();
//var divToScroll = document.getElementsByClassName('content scrollable header')[0],
//    scrollPosition = divToScroll.scrollDown;
}

 function cblue() {
 document.getElementById("colorimg").src="./images/colors/color-blue.png";
document.getElementById("colortxt").textContent="Medium Blue Mica";
scrollToAnchor('divtop');
};



 function cblack() {
 document.getElementById("colorimg").src="./images/colors/color-black.png";
document.getElementById("colortxt").textContent="Pyrenese Black";
scrollToAnchor('divtop');
};

 function csavanna() {
 document.getElementById("colorimg").src="./images/colors/color-savanna.png";
document.getElementById("colortxt").textContent="Savanna White";
scrollToAnchor('divtop');
};
 function cred() {
 document.getElementById("colorimg").src="./images/colors/color-red.png";
document.getElementById("colortxt").textContent="Majestic Red";
scrollToAnchor('divtop');
};
 function cgrey() {
 document.getElementById("colorimg").src="./images/colors/color-gray.png";
document.getElementById("colortxt").textContent="Gemstone Grey Mica";
scrollToAnchor('divtop');
};
 function csilver() {
 document.getElementById("colorimg").src="./images/colors/color-silver.png";
document.getElementById("colortxt").textContent="Cool Silver";
scrollToAnchor('divtop');
};


 function caurora() {
 document.getElementById("colorimg").src="./images/colors/color-aurora.png";
document.getElementById("colortxt").textContent="Aurora White";
scrollToAnchor('colorimg');
};